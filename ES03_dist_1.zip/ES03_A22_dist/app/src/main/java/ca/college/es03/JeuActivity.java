package ca.college.es03;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;


public class JeuActivity extends AppCompatActivity {

    private static final String sNomFichier = "usa.json";

    // Source de données
    private ArrayList<Etat> mlisteEtats;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jeu);

        // Lire les données du fichier dans mlisteEtats
        mlisteEtats = Etat.lireDonnees(this, sNomFichier);

    }
}