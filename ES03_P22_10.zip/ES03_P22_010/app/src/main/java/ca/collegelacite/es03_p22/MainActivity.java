package ca.collegelacite.es03_p22;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import java.util.ArrayList;

/***
 *
    Nom Etudiant :  <Compléter>
    Groupe:         <Compléter>
    Evaluation:     ES03
    Session:        Printemps 2022
 *
***/
public class MainActivity extends AppCompatActivity {

    static private final String nomFichier = "pays.json";

    // GridView <---> adaptateur <---> Données

    // Adaptateur faisant le pont entre GridView w et les données.

    // Fonction du cycle de vie exécutée lors de la création de l'activité.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Données source de l'adaptateur
        ArrayList<Pays> listePays = Pays.lireFichier(this, nomFichier);


    }

}